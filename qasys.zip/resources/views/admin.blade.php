@extends('master')
@section('title','Course')
@section('content')
<div class="row">
    <h1>Admin</h1>
</div>
<!-- end row-->


@endsection
