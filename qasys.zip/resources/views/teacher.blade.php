@extends('master')
@section('title','Course')
@section('content')
<div class="row">
    <h1>Teacher</h1>
</div>
<!-- end row-->


@endsection
