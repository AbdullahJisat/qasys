@extends('master')
@section('title','Course')
@section('content')
<div class="row">
    <h1>Student</h1>
</div>
<!-- end row-->


@endsection
