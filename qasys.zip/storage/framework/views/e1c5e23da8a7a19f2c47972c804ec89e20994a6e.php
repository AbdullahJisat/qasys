<!DOCTYPE html>
<html lang="en">

<head>

        <meta charset="utf-8" />
        <title>Dashboard | UBold - Responsive Admin Dashboard Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="https://coderthemes.com/ubold/layouts/assets/images/favicon.ico">
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.11.2/css/jquery.dataTables.min.css">

        <!-- Plugins css -->
        <link href="<?php echo e(asset('components')); ?>/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('components')); ?>/libs/selectize/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('components')); ?>/libs/dropify/css/dropify.min.css" rel="stylesheet" type="text/css" />


        <!-- App css -->
        <link href="<?php echo e(asset('components')); ?>/css/config/default/bootstrap.min.css" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
        <link href="<?php echo e(asset('components')); ?>/css/config/default/app.min.css" rel="stylesheet" type="text/css" id="app-default-stylesheet" />

        <link href="<?php echo e(asset('components')); ?>/css/config/default/bootstrap-dark.min.css" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" />
        <link href="<?php echo e(asset('components')); ?>/css/config/default/app-dark.min.css" rel="stylesheet" type="text/css" id="app-dark-stylesheet" />

        <!-- icons -->
        <link href="<?php echo e(asset('components')); ?>/css/icons.min.css" rel="stylesheet" type="text/css" />

        <!-- Bootstrap Tables css -->
        <link href="<?php echo e(asset('components')); ?>/libs/bootstrap-table/bootstrap-table.min.css" rel="stylesheet" type="text/css" />

    </head>

    <!-- body start -->
    <body class="loading" data-layout='{"mode": "light", "width": "fluid", "menuPosition": "fixed", "sidebar": { "color": "light", "size": "default", "showuser": false}, "topbar": {"color": "dark"}, "showRightSidebarOnPageLoad": true}'>

        <!-- Begin page -->
        <div id="wrapper">

            <?php if ($__env->exists('partials.topbar')) echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if ($__env->exists('partials.navbar')) echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ============================================================== -->
            <?php if ($__env->exists('partials.bodycontent')) echo $__env->make('partials.bodycontent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        

        <!-- Right bar overlay-->
        

        <script  src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.min.js"></script>
        <!-- Vendor js -->
        <script src="<?php echo e(asset('components')); ?>/js/vendor.min.js"></script>

        <!-- Plugins js-->
        <script src="<?php echo e(asset('components')); ?>/libs/flatpickr/flatpickr.min.js"></script>
        <script src="<?php echo e(asset('components')); ?>/libs/apexcharts/apexcharts.min.js"></script>

        <script src="<?php echo e(asset('components')); ?>/libs/selectize/js/standalone/selectize.min.js"></script>

        <!-- Dashboar 1 init js-->
        <script src="<?php echo e(asset('components')); ?>/js/pages/dashboard-1.init.js"></script>

        <!-- App js-->
        <script src="<?php echo e(asset('components')); ?>/js/app.min.js"></script>

        <!-- Bootstrap Tables js -->
        <script src="<?php echo e(asset('components')); ?>/libs/bootstrap-table/bootstrap-table.min.js"></script>

        <!-- Init js -->
        <script src="<?php echo e(asset('components')); ?>/js/pages/bootstrap-tables.init.js"></script>

        <script src="<?php echo e(asset('components')); ?>/js/pages/form-fileuploads.init.js"></script>

        <!-- Plugin js-->
        <script src="<?php echo e(asset('components')); ?>/libs/parsleyjs/parsley.min.js"></script>

        <!-- Validation init js-->
        <script src="<?php echo e(asset('components')); ?>/js/pages/form-validation.init.js"></script>

        <!-- Plugins js -->
        <script src="<?php echo e(asset('components')); ?>/libs/dropzone/min/dropzone.min.js"></script>
        <script src="<?php echo e(asset('components')); ?>/libs/dropify/js/dropify.min.js"></script>

        <!-- Init js-->


    </body>

<!-- Mirrored from coderthemes.com/ubold/layouts/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 21 Sep 2021 07:43:29 GMT -->
</html>
<?php /**PATH C:\laragon\www\qasys\resources\views/master.blade.php ENDPATH**/ ?>