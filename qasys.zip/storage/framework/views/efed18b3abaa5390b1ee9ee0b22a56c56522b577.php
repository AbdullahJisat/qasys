<?php $__env->startSection('title','Question Answer'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                

                
                    <form action="<?php echo e(route('ques-ans.store')); ?>" method="post" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="fullname" class="form-label">Course</label>
                        <select class="form-control" name="course_id" id="">
                            <option value="">Select Course</option>
                            <?php $__currentLoopData = App\Models\Course::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="fullname" class="form-label">Name</label>
                        <input type="text" class="form-control" name="name" id="name" required="">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Type</label>

                        <div class="form-check mb-1">
                            <input type="radio" name="type" id="genderM" value="1" required="" class="form-check-input">
                            <label for="genderM">MCQ</label>
                        </div>
                        <div class="form-check">
                            <input type="radio" name="type" id="genderF" value="0" class="form-check-input">
                            <label for="genderF">Other</label>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="fullname" class="form-label">File Upload</label>
                        <input type="file" class="form-control" name="file" id="file" required="">
                    </div>

                    <div class="mb-3">
                        <label for="fullname" class="form-label">File Ans</label>
                        <input type="file" class="form-control" name="is_ans" id="" required="">
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea id="description" class="form-control" name="description"
                            data-parsley-trigger="keyup" data-parsley-minlength="20"
                            data-parsley-maxlength="100"
                            
                            data-parsley-validation-threshold="10">
                        </textarea>
                    </div>

                    <div>
                        <input type="submit" class="btn btn-success" value="Save">
                    </div>

                </form>
            </div>
        </div> <!-- end card-->
    </div> <!-- end col-->
</div>
<!-- end row-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\qasys\resources\views/pages/question_answer/create.blade.php ENDPATH**/ ?>