<?php $__env->startSection('title','Course'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <h1>Teacher</h1>
</div>
<!-- end row-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\qasys\resources\views/teacher.blade.php ENDPATH**/ ?>