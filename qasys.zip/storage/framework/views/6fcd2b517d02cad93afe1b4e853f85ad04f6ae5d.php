<?php $__env->startSection('title','Course'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <h1>Student</h1>
</div>
<!-- end row-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\qasys\resources\views/student.blade.php ENDPATH**/ ?>