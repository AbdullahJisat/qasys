<?php $__env->startSection('content'); ?>
<div class="w3-container w3-text-black  w3-large" id="jeans">
    <p>Questions by Course</p>
  </div>
<?php $__currentLoopData = $quesAns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ques): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="w3-col l3 s6">
    <div class="w3-container">
        <div class="w3-display-container">
        <img
            src="https://helpx.adobe.com/content/dam/help/en/photoshop/using/convert-color-image-black-white/jcr_content/main-pars/before_and_after/image-before/Landscape-Color.jpg"
            style="width:100%">
        <span class="w3-tag w3-display-topleft">New</span>
        <div class="w3-display-middle w3-display-hover">
            <a href="<?php echo e(url('/buy-ques')); ?>" class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></a>
        </div>
        </div>
        <p><?php echo e($ques->name); ?><br><b>$19.99</b></p>
    </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.main-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\qasys\resources\views/main/ques-course.blade.php ENDPATH**/ ?>