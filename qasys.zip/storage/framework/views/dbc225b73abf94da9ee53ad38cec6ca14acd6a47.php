<!-- ========== Left Sidebar Start ========== -->
<div class="left-side-menu">

    <div class="h-100" data-simplebar>

        <!-- User box -->
        <div class="user-box text-center">
            <img src="../assets/images/users/user-1.jpg" alt="user-img" title="Mat Helme"
                class="rounded-circle avatar-md">
            <div class="dropdown">
                <a href="javascript: void(0);" class="text-dark dropdown-toggle h5 mt-2 mb-1 d-block"
                    data-bs-toggle="dropdown">Geneva Kennedy</a>
                <div class="dropdown-menu user-pro-dropdown">

                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                        <i class="fe-user me-1"></i>
                        <span>My Account</span>
                    </a>

                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                        <i class="fe-settings me-1"></i>
                        <span>Settings</span>
                    </a>

                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                        <i class="fe-lock me-1"></i>
                        <span>Lock Screen</span>
                    </a>

                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                        <i class="fe-log-out me-1"></i>
                        <span>Logout</span>
                    </a>

                </div>
            </div>
            <p class="text-muted">Admin Head</p>
        </div>

        <!--- Sidemenu -->
        <div id="sidebar-menu">

            <ul id="side-menu">

                <li class="menu-title">Navigation</li>

                <?php if(Auth::user()->user_type == 'teacher'): ?>
                <li>
                    <a href="<?php echo e(route('teacher')); ?>" data-bs-toggle="collapse">
                        <i data-feather="airplay"></i>
                        <span> Dashboard </span>
                    </a>
                </li>
                <?php elseif(Auth::user()->user_type == 'student'): ?>
                <li>
                    <a href="<?php echo e(route('student')); ?>">
                        <i data-feather="airplay"></i>
                        <span> Dashboard </span>
                    </a>
                </li>
                <?php else: ?>
                <li>
                    <a href="<?php echo e(route('admin')); ?>" data-bs-toggle="collapse">
                        <i data-feather="airplay"></i>
                        <span> Dashboard </span>
                    </a>
                </li>
                <?php endif; ?>

                

                <li>
                    <a href="#sidebarEcommerce" data-bs-toggle="collapse">
                        <i data-feather="shopping-cart"></i>
                        <span> Course </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="sidebarEcommerce">
                        <ul class="nav-second-level">
                            <li>
                                <a href="<?php echo e(route('course.index')); ?>">View Course</a>
                            </li>
                            <?php if(Auth::user()->user_type == 'admin'): ?>
                            <li>
                                <a href="<?php echo e(route('course.create')); ?>">Add Course</a>
                            </li>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo e(route('course.assign')); ?>">Course Assign Teacher</a>
                            </li>
                            <?php if(Auth::user()->user_type == 'admin'): ?>
                            <li>
                                <a href="<?php echo e(route('course.assign-teacher')); ?>">Add Course Assign</a>
                            </li>
                            <?php endif; ?>
                            <?php if(auth()->user()->user_type == 'student' || Auth::user()->user_type == 'admin'): ?>
                            <li>
                                <a href="<?php echo e(route('course.assign-index')); ?>">Course Assign View</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('course.assign-student')); ?>">Course Assign Add</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>

                <?php if(Auth::user()->user_type == 'teacher' || Auth::user()->user_type == 'admin'): ?>
                    <li>
                        <a href="#sidebarCrm" data-bs-toggle="collapse">
                            <i data-feather="users"></i>
                            <span> Ques Ans </span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse" id="sidebarCrm">
                            <ul class="nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('ques-ans.index')); ?>">View Ques Ans</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('ques-ans.create')); ?>">Add Ques Ans</a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <li>
                        <a href="#sidebarSend" data-bs-toggle="collapse">
                            <i data-feather="users"></i>
                            <span> Send Link </span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse" id="sidebarSend">
                            <ul class="nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('send-link.index')); ?>">View Send Link</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('send-link.create')); ?>">Add Send Link</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="#sidebarSend" data-bs-toggle="collapse">
                            <i data-feather="users"></i>
                            <span> Send Link </span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse" id="sidebarSend">
                            <ul class="nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('send-link.student-index')); ?>">View Send Link</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>


            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End -->
<?php /**PATH C:\laragon\www\qasys\resources\views/partials/navbar.blade.php ENDPATH**/ ?>